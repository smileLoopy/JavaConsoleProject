package banking;

public class MenuSelectException {

}
