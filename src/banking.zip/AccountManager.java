package banking;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

//해당 프로그램에서 기능을 담당하는 클래스 즉, 핸들러 클래스 혹은 매니저클래스라고 한다. 
public class AccountManager  {
	
	/*
	기본 객체배열에 저장하던 방식을 List계열의 컬렉션으로 변경한다.
	우리는 배열과 동일한 특징을 가지고 있는 ArrayList<E>로 객체를 생성한다.
	해당 컬렉션에는 Account 타입의 객체를 저장할 것이다. 따라서 상속관계가 있는
	하위 객체들을 모두 저장할 수 있다. 
	 */
	
	private ArrayList <Account> myAccounts;
	private ArrayList <NormalAccount> myNormalAccounts;
	private ArrayList <HighCreditAccount> myHighCreditAccounts;
	
//	
//	int choice;
	
	//생성자
	public AccountManager (int num) {
		
		//멤버변수로 선언한 List컬렉션의 객체를 생성한다.
		myAccounts = new ArrayList<Account>();
		myNormalAccounts = new ArrayList<NormalAccount>();
		myHighCreditAccounts = new ArrayList<HighCreditAccount>();
		/*
		List<E> 계열의 컬렉션은 인덱스가 존재하긴 하나 자동 인덱싱을 지원하므로
		인덱스 저장을 위한 변수는 필요 없다. ex) numOfAccounts = 0;
		 */
	}

	
	public void makeAccount() {
		
		//계좌정보 입력받음. 
		Scanner scan = new Scanner (System.in);
		String accountNum;
		String name;
		int balance;
		int nInterest;
		int hInterest;
		String creditRate;
		int choice;
		
		System.out.println("***신규계좌개설***");
		System.out.println("---계좌선택---");
		System.out.println("1.보통계좌");
		System.out.println("2.신용신뢰계좌");
		System.out.print("선택:"); choice = scan.nextInt();
		
		scan.nextLine();
		System.out.println("계좌번호:"); accountNum = scan.nextLine();
		System.out.println("이름:"); name = scan.nextLine();
		System.out.println("잔고:"); balance = scan.nextInt();
		
		
		/*
		List<E> 컬렉션에 객체를 추가할때는 add()메서드를 사용한다.
		추가하면 자동으로 인덱스가 부여되므로 별도의 처리가 필요하지 않다.
		단, 인덱스를 건너뛸수는 없다. 
		 */
		if(choice==1) {
			
			System.out.println("기본이자%(정수형태로입력):"); nInterest  = scan.nextInt();
			NormalAccount normalAccount = 
					new NormalAccount(accountNum, name, balance, nInterest);
			myNormalAccounts.add(normalAccount);
			
		}
		else if (choice==2) {
			
			
			System.out.println("기본이자%(정수형태로입력):"); hInterest = scan.nextInt();
			scan.nextLine();
			System.out.println("신용등급(A,B,C등급):"); creditRate = scan.nextLine();
			HighCreditAccount highCreditAccount = 
					new HighCreditAccount(accountNum, name, balance, hInterest, creditRate);
			myHighCreditAccounts.add(highCreditAccount);
			
		}
			
		System.out.println("계좌계설이 완료되었습니다.");
		
	}
	
	//입금
	public void depositMoney() {
		
		//일반계좌: 잔고 + (잔고*기본이자) + 입금액
		//신용계좌: 잔고 + (잔고*기본이자) + (잔고*추가이자) + 입금액
			//A:7%, B:4%, C:2%
		
		//검색한 계좌정보가 없는 경우 false를 유지한다. 
		boolean isFind = false;
		Scanner scan = new Scanner (System.in);
		System.out.println("계좌번호와 입금할 금액을 입력하세요");
		System.out.println("계좌번호:");
		String searchAccountNum = scan.nextLine();
		System.out.println("입금액:");
		int money = scan.nextInt();
				
		
		for(NormalAccount na : myNormalAccounts) {
			
			if(searchAccountNum.equals(na.accountNum)) {
				
				System.out.println("***입금***");
				na.balance = na.balance  + (na.balance * na.nInterest/100) + money;
				isFind  = true;
				System.out.println("입금이 완료되었습니다.");
				break;
				}			
		}		
		
//		isFind = false;
		for(HighCreditAccount hca : myHighCreditAccounts) {
			if(searchAccountNum.equals(hca.accountNum)) {
				
				if(hca.creditRate.equals("A")) {
					System.out.println("***입금***");
					hca.balance = (int) (hca.balance + (hca.balance*hca.hInterest/100) + 
								(hca.balance * 0.07)) + money ;
					isFind = true;
					System.out.println("입금이 완료되었습니다.");
					break;
				
				}
				else if (hca.creditRate.equals("B")) {
					System.out.println("***입금***");
					hca.balance = (int) (hca.balance + (hca.balance*hca.hInterest/100) + 
								(hca.balance * 0.04)) + money ;
					isFind = true;
					System.out.println("입금이 완료되었습니다.");
					break;
					
				}
				else if (hca.creditRate.equals("C")) {
					System.out.println("***입금***");
					hca.balance = (int) (hca.balance + (hca.balance*hca.hInterest/100) + 
								(hca.balance * 0.02)) + money ;
					isFind = true;
					System.out.println("입금이 완료되었습니다.");
					System.out.println("creditRate"+ hca.creditRate);
					break;
				}
			}			
			if (isFind == false) {
				System.out.println("입력하신 계좌번호는 존재하지 않습니다.222");
			}
		}
		}	
	
	
	//출금
	public void withdrawMoney() {
		
		
		//검색한 계좌정보가 존재하는 지 확인하는 변수 
		boolean isFind = false;
		Scanner scan = new Scanner (System.in);
		System.out.println("계좌번호와 입금할 금액을 입력하세요");
		System.out.println("계좌번호:");
		String searchAccountNum = scan.nextLine();
		System.out.println("출금액:");
		int money = scan.nextInt();
		
		
		Iterator <NormalAccount> itr = myNormalAccounts.iterator();
		while(itr.hasNext()) {
			NormalAccount na = itr.next();
			if(searchAccountNum.equals(na.accountNum)) {
				System.out.println("***출금***");
				na.balance = na.balance - money;
				System.out.println("출금이 완료되었습니다.");
				isFind = true;
			}
		}
		
		Iterator <HighCreditAccount> itr2 = myHighCreditAccounts.iterator();
		while(itr.hasNext()) {
			HighCreditAccount hca = itr2.next();
			if(searchAccountNum.equals(hca.accountNum)) {
				System.out.println("***출금***");
				hca.balance = hca.balance - money;
				System.out.println("출금이 완료되었습니다.");
				isFind = true;
			}
		}
		
		if(isFind == false) System.out.println("입력한 계좌번호는 존재하지 않습니다.");

		
		
	}
	
	//전체정보 출력용
	public void showAccInfo () {
		
		//iterator 대신 확장 for문으로 대체
		for(NormalAccount na : myNormalAccounts) {
			na.showAccInfo();
		}
		
		for(HighCreditAccount hca : myHighCreditAccounts) {
			hca.showAccInfo();
		}
		
//		Iterator<NormalAccount> itr1 = myNormalAccounts.iterator();
//		while (itr1.hasNext()) {
//			NormalAccount ac = itr1.next();
//			ac.showAccInfo();
//			
//		}
//		
//		Iterator<HighCreditAccount> itr2 = myHighCreditAccounts.iterator();
//		while (itr2.hasNext()) {
//			HighCreditAccount hca = itr2.next();
//			hca.showAccInfo();
//		}
		System.out.println("전체계좌정보 출력이 완료되었습니다.");
		
	}
	
}
