package banking;

import java.util.Scanner;

public class BankingSystemMain implements ICustomDefine {
	
	
	public static void menuShow () {
		System.out.println("------ Menu ------");
		System.out.println("1.계좌개설 ");
		System.out.println("2.입금 ");
		System.out.println("3.출금 ");
		System.out.println("4.계좌정보출력 ");
		System.out.println("5.프로그램종료 ");
		System.out.println("선택:");
		
		
	}

	public static void main(String[] args) {
		
		//사용자 입력을 위한 객체 생성
		Scanner scan = new Scanner (System.in);
		
		/*
		기능을 담당하는 핸들러(메니저) 클래스의 객체 생성
		초깃값으로 50개의 계좌정보를 저장할 수 있는 Account타입의 객체배열을 생성한다
		 */
		Account account = new Account ();
		AccountManager accountManager = new AccountManager (50);
		
		while (true) {
			//메뉴를 출력한다.
			menuShow();
			
			//사용자는 수행할 기능의 메뉴를 선택한다.
			int choice = scan.nextInt();
			
			if(choice == MAKE) {
				accountManager.makeAccount();
			}
			else if (choice == DEPOSIT) {
				accountManager.depositMoney();
			}
			else if (choice == WITHDRAW) {
				accountManager.withdrawMoney();
			}
			else if (choice == INQUIRE) {
				accountManager.showAccInfo();
			}
			else if (choice == EXIT) {
				System.out.println("프로그램종료");
				return; //main의 종료는 프로그램의 종료로 이어진다.
			}
			
		}
		
	}
}
