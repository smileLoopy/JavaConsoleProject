package banking;

public interface ICustomDefine {
	
	public static final int MAKE = 1;
	public static final int DEPOSIT = 2;
	public static final int WITHDRAW = 3;
	public static final int INQUIRE = 4;
	public static final int EXIT = 5;
	

}
