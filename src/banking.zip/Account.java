package banking;

public class Account { //데이터 클래스 
	//멤버변수: 계좌 기본정보 3가지 
	String accountNum;
	String name;
	int balance;
	
	public Account () {
		
	}
	
	
	//인자 생성자 
	public Account (String accountNum, String name, int balance) {
		this.accountNum = accountNum;
		this.name = name;
		this.balance = balance;
	}
	/*
	멤버변수 전체 정보를 출력할 목적의 멤버베서드 
	 */
	public void showAccInfo() {
		System.out.println("***계좌정보출력***");
		System.out.println("----------");
		System.out.println("계좌번호>"+ accountNum);
		System.out.println("고객이름>"+ name);
		System.out.println("잔고>"+ balance);
		System.out.println("----------");
		
	}
}



