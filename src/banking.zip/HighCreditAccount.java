package banking;

public class HighCreditAccount extends Account {
	
	
	int hInterest;
	String creditRate;
	
	public HighCreditAccount (String accountNum, String name, int balance, int hInterest ,String creditRate) {
		
		super(accountNum, name, balance);
		this.hInterest = hInterest;
		this.creditRate = creditRate;
		
	}
	
	@Override
	public void showAccInfo() {
		System.out.println("==신용신뢰계좌(전체정보)==");
		super.showAccInfo();
		System.out.println("기본이자>" +hInterest);
		System.out.println("신용등급>"+ creditRate);
	}

}
