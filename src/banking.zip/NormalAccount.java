package banking;
/*
이자계산방식 : 잔고:5000원, 기본이자:2%, 신용등급이자:4%, 입금액:2000원이라 가정하면….
일반계좌 : 잔고 + (잔고 * 기본이자) + 입금액 
Ex) 5000 + (5000 * 0.02) + 2000 = 7,100원
신용계좌 : 잔고 + (잔고 * 기본이자) + (잔고 * 추가이자) + 입금액
Ex) 5000 + (5000 * 0.02) + (5000 * 0.04) + 2000 = 7,300원
 */

import java.util.Scanner;

public class NormalAccount extends Account {

	
	//자식에서 확장한 멤버변수
	int nInterest; //이자
	
	//인자 생성자
	public NormalAccount (String accountNum, String name, int balance, int nInterest) {
		super(accountNum, name, balance);
		this.nInterest = nInterest;
		
	}
	/*
	 보통예금계좌 전체정보를 출력하기 위해 부모에서 정의된 메서드를 super를 통해
	 호출하고, 자식에서 확장한 변수를 별도의 print문을 통해 출력한다.
	 */
	@Override
	public void showAccInfo() {
		System.out.println("==보통예금계좌(전체정보)==");
		super.showAccInfo();
		System.out.println("기본이자>" +nInterest);
	}


}
